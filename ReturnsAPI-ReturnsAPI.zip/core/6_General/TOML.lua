-- TOML

--[[
Slightly easier syntax wrapper for `toml`.
Files are stored in `paths.plugins_data()` (or `paths.config()` if `new_config()` is used).
]]

TOML = new_class()

__toml_directories = __toml_directories or setmetatable({}, {__mode = "k"})



-- ========== Properties ==========

--@section Properties

--[[
**Wrapper**
Property | Type | Description
| - | - | -
`value`         | number    | *Read-only.* The filename being used.
`RAPI`          | string    | *Read-only.* The wrapper name.
`path`          | string    | *Read-only.* The filepath being used.
]]



-- ========== Static Methods ==========

--@section Static Methods

--@static
--@return       TOML
--@optional     name        | string    | The filename to use. <br>Automatically prepended with your namespace. <br>Adding an extension is *not* required; `".toml"` is automatically appended.
--@optional     directory   | string    | The directory to create in. <br>`paths.plugins_data()` by default.
--[[
Creates a new TOML wrapper and returns it.
]]
TOML.new = function(NAMESPACE, name, directory)
    local proxy = make_proxy(NAMESPACE..((name and "-"..tostring(name)) or ""), metatable_toml)
    __toml_directories[proxy] = directory or paths.plugins_data()
    return proxy
end



-- ========== Instance Methods ==========

--@section Instance Methods

methods_toml = {

    --@instance
    --@return       table or nil
    --[[
    Loads the stored data from the file.
    Returns `nil` if the file does not exist.
    ]]
    read = function(self)
        local success, file = pcall(toml.decodeFromFile, self.path)
        if not success then
            -- Ignore non-existent file error
            if file.reason == "File could not be opened for reading" then
                return
            end

            log.error("toml read error: "..file.reason, 2)
        end
        return file
    end,


    --@instance
    --@param        table           | table     | The table to write.
    --[[
    Overwrites the file with a table.
    ]]
    write = function(self, t)
        local success, err = pcall(toml.encodeToFile, t, { file = self.path, overwrite = true })
        if not success then log.error("toml write error: "..err, 2) end
    end

}



-- ========== Metatables ==========

local wrapper_name = "TOML"

make_table_once("metatable_toml", {
    __index = function(proxy, k)
        -- Get wrapped value
        if k == "value" then return __proxy[proxy] end
        if k == "RAPI" then return wrapper_name end
        if k == "path" then
            return path.combine(__toml_directories[proxy], __proxy[proxy]..".toml")
        end

        -- Methods
        if methods_toml[k] then
            return methods_toml[k]
        end

        return nil
    end,


    __newindex = function(proxy, k, v)
        -- Throw read-only error for certain keys
        if k == "value"
        or k == "RAPI"
        or k == "path" then
            log.error("Key '"..k.."' is read-only", 2)
        end

        -- Setter
        log.error("TOML has no properties to set", 2)
    end,


    __metatable = "RAPI.Wrapper."..wrapper_name
})



-- Public export
__class.TOML = TOML